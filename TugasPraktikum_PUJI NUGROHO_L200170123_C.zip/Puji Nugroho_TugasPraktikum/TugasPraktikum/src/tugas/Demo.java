/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package tugas;


import javax.swing.JFrame;
import javax.swing.JTabbedPane;

/**
 *
 * @author User
 */
public class Demo {
     public static void main(String[] args) {
        JFrame frame = new JFrame("Tugas dengan border layout");
        frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        
        JTabbedPane tp = new JTabbedPane();
        tp.addTab("Nomor 1", new coba1());
        tp.addTab("Nomor 2", new coba2());
        
        frame.getContentPane().add(tp);
        frame.pack();
        frame.setSize(600, 300);
        frame.setVisible(true);
    }
}
