/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package tugas;

import java.awt.Color;
import java.awt.GridLayout;
import javax.swing.JButton;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JPanel;

/**
 *
 * @author User
 */
public class coba3 extends JPanel{
    public coba3(){
        setLayout(new GridLayout(2, 3, 5, 10));

        
        JLabel b1 = new JLabel("Timur");
        b1.setBackground(Color.red);
        b1.setOpaque(true);
        b1.setSize(100, 50);
        
        JLabel b2 = new JLabel("Barat");
        b2.setBackground(Color.blue);
        b2.setOpaque(true);
        b1.setSize(150, 100);
        
        JLabel b3 = new JLabel("Utara");
        b3.setBackground(Color.green);
        b3.setOpaque(true);
        b1.setSize(150, 100);
        
        JLabel b4 = new JLabel("Selatan");
        b4.setBackground(Color.yellow);
        b4.setOpaque(true);
        b1.setSize(150, 100);
        
        JLabel b5 = new JLabel("Pusat");
        b5.setBackground(Color.orange);
        b5.setOpaque(true);
        b1.setSize(150, 100);
        
        add(b1);
        add(b2);
        add(b4);
        add(b3);
        add(b5);
    }
    
    public static void main(String[] args) {
        JFrame frame = new JFrame("Tugas dengan border layout");
        frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        
        frame.getContentPane().add(new coba3());
        frame.pack();
        frame.setSize(600, 300);
        frame.setVisible(true);
    }
}
